#include <iostream>
#include "../utils/algorithmUtils.h"

int main(int argc, char *argv[]) {
    std::cout << IsInRange(1, 2, 3) << std::endl;
}
