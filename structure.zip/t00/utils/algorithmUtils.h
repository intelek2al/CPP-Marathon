#pragma once

template<typename T>
bool IsInRange(const T& val, const T& from, const T& to) {
    return true;
}
